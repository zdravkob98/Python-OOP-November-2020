from project.animals_base import AnimalBase


class Cheetah(AnimalBase):
    needs = 60
