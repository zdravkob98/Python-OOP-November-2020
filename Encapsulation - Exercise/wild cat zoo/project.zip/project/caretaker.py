from project.emploee_base import EmploeeBase


class Caretaker(EmploeeBase):
    pass
