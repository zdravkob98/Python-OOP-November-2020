from project.animals_base import AnimalBase


class Lion(AnimalBase):
    needs = 50
