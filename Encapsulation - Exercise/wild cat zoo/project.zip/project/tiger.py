from project.animals_base import AnimalBase


class Tiger(AnimalBase):
    needs = 45
