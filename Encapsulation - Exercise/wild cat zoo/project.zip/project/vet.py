from project.emploee_base import EmploeeBase


class Vet(EmploeeBase):
    pass
