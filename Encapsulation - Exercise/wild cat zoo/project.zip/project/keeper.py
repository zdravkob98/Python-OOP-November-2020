from project.emploee_base import EmploeeBase


class Keeper(EmploeeBase):
    pass
