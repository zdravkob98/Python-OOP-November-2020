class Zoo:

    def __init__(self, name: str, budget: float, animal_capacity: int, workers_capacity: int):
        self.name = name
        self.animals = []
        self.workers = []
        self.__animal_capacity = animal_capacity
        self.__workers_capacity = workers_capacity
        self.__budget = budget

    def add_animal(self, animal, price: int):
        if price <= self.__budget and len(self.animals) + 1 <= self.__animal_capacity:
            self.animals.append(animal)
            self.__budget -= price
            return f'{animal.name} the {animal.type} added to the zoo'

        elif len(self.animals) + 1 <= self.__animal_capacity and price > self.__budget:
            return 'Not enough budget'

        else:
            return 'Not enough space for animal'

    def hire_worker(self, worker):
        if len(self.workers) + 1 <= self.__workers_capacity:
            self.workers.append(worker)
            return f'{worker.name} the {worker.type} hired successfully'
        return 'Not enough space for worker'

    def fire_worker(self, worker_name: str):
        worker_to_fire = [worker for worker in self.workers if worker.name == worker_name]

        if worker_to_fire:
            name = worker_to_fire[0].name
            self.workers.remove(worker_to_fire[0])
            return f'{name} fired successfully'
        return f'There is no {worker_name} in the zoo'

    def pay_workers(self):
        total_salaries = sum([worker.salary for worker in self.workers])
        if self.__budget - total_salaries >= 0:
            self.__budget -= total_salaries
            return f'You payed your workers. They are happy. Budget left: {self.__budget}'
        return f'You have no budget to pay your workers. They are unhappy'

    def tend_animals(self):
        total_animal_costs = sum([animal.get_needs() for animal in self.animals])
        if self.__budget - total_animal_costs >= 0:
            self.__budget -= total_animal_costs
            return f'You tended all the animals. They are happy. Budget left: {self.__budget}'
        return 'You have no budget to tend the animals. They are unhappy.'

    def profit(self, amount: int):
        self.__budget += amount

    def animals_status(self):
        result = f'You have {len(self.animals)} animals\n'

        result += f'----- {len([animal for animal in self.animals if animal.type == "Lion"])} Lions:'
        for animal in self.animals:
            if animal.type == 'Lion':
                result += f'\n{animal.__repr__()}'

        result += f'\n----- {len([animal for animal in self.animals if animal.type == "Tiger"])} Tigers:'
        for animal in self.animals:
            if animal.type == 'Tiger':
                result += f'\n{animal.__repr__()}'

        result += f'\n----- {len([animal for animal in self.animals if animal.type == "Cheetah"])} Cheetahs:'
        for animal in self.animals:
            if animal.type == 'Cheetah':
                result += f'\n{animal.__repr__()}'

        return result

    def workers_status(self):
        result = f'You have {len(self.workers)} workers\n'

        result += f'----- {len([worker for worker in self.workers if worker.type == "Keeper"])} Keepers:'
        for worker in self.workers:
            if worker.type == 'Keeper':
                result += f'\n{worker.__repr__()}'
        
        result += f'\n----- {len([worker for worker in self.workers if worker.type == "Caretaker"])} Caretakers:'
        for worker in self.workers:
            if worker.type == 'Caretaker':
                result += f'\n{worker.__repr__()}'

        result += f'\n----- {len([worker for worker in self.workers if worker.type == "Vet"])} Vets:'
        for worker in self.workers:
            if worker.type == 'Vet':
                result += f'\n{worker.__repr__()}'

        return result











