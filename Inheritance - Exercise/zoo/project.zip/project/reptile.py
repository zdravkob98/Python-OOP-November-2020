from .animal import Animal


class Reptile(Animal):
    pass
