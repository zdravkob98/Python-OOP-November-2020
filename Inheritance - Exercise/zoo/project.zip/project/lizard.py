from .reptile import Reptile


class Lizard(Reptile):
    pass