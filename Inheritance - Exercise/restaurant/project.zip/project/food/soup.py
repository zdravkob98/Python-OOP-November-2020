#from restaurant.project.food.starter import Starter
from project.food.starter import Starter

class Soup(Starter):
    pass
