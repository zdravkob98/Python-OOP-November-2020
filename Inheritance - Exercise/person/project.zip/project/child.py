from .person import Person


class Child(Person):
    pass